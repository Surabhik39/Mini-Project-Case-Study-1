import { Component, OnInit } from '@angular/core';
import { UserService } from '../../app/user.service';
import { Router } from '@angular/router';
import { DataStruct } from '../../Entities/dataStruct';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-product-display',
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent implements OnInit {

  constructor(private user: UserService, private router: Router) { }
   public data: DataStruct[] = [];
   public id:number;
   public name:string;
   public desc:string;
   public price:number;
   public prodId:number;
   public prodName:string;
   public prodDes:string;
   public prodPrice:number;
   p:number=1;

  ngOnInit() {
    this.getData();
  }

  getData(){
    this.user.getData().subscribe(data => this.data=data);
    //console.log(this.data);
    // return false;
  }
  
  addProduct(f:NgForm){
    //this.router.navigate(['/addProduct']);
    this.user.postData(this.id, this.name, this.desc, this.price).subscribe((data:DataStruct[]) => this.data = data);
    f.resetForm();
  }
 
  deleteAll()
  {
    if (confirm("Are you sure to delete all records?")) {
        this.user.deleteAll().subscribe((data:DataStruct[]) => this.data = data);
} 
  }

  editfun(id){
    for(var prod of this.data){
      if(prod.id==id){
        this.prodId = prod.id;
        this.prodName = prod.Name;
        this.prodDes = prod.Description;
        this.prodPrice = prod.Price;
        console.log(this.prodId,this.prodName,this.prodDes,this.prodPrice);
        console.log("EditFun OUt");
      }
    }
  }
  updateProduct(id:number,name:string,des:string,price:number){
    console.log(id);
        this.prodId = id;
        this.prodName = name;
        this.prodDes = des;
        this.prodPrice = price;
        console.log(this.prodId,this.prodName,this.prodDes,this.prodPrice);
        console.log("UpdateData OUt");
    console.log(this.prodId,this.prodName,this.prodDes,this.prodPrice);
    this.user.updateData(this.prodId, this.prodName, this.prodDes, this.prodPrice).subscribe((data:DataStruct[]) => this.data = data);
   
  }
  remove(id:number){
    this.user.removeData(id).subscribe((data:DataStruct[]) => this.data = data);
  
  }
}
