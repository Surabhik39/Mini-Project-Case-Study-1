import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from "@angular/router";
import { AppComponent } from './app.component';
import { ProductDisplayComponent } from '../component/ProductDisplay/product-display.component';
import { AddProductComponent } from '../component/AddProduct/add-product.component';
import { EditProductComponent } from '../component/EditProduct/edit-product.component';

const appRoutes:Routes = [
   {
      path: '',
      component: ProductDisplayComponent
   },
   {
     path: 'addProduct',
     component: AddProductComponent
   },
   {
     path: 'editProduct',
     component: EditProductComponent
   }
]

@NgModule({
   exports: [ RouterModule ],
  imports: [
   RouterModule.forRoot( appRoutes)
  ],
  declarations: []
})
export class AppRoutingModule { }
