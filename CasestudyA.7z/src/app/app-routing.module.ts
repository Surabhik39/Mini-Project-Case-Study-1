import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from "@angular/router";
import { AppComponent } from './app.component';
import { ProductDisplayComponent } from '../component/ProductDisplay/product-display.component';

const appRoutes:Routes = [
   {
      path: '',
      component: ProductDisplayComponent
   }
]

@NgModule({
   exports: [ RouterModule ],
  imports: [
   RouterModule.forRoot( appRoutes)
  ],
  declarations: []
})
export class AppRoutingModule { }
